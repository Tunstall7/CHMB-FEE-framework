function sim = extractSim(j)
    expPath  = 'C:\Projects\HEC\DSS\export';
    runNames = {'Run01'};
    outName  = sprintf('Run%02d_%s', j, runNames{j});
    simPath  = fullfile(expPath, outName);

    stripCommas(simPath);

    [~, name] = fileparts(simPath);
    txtPath   = fullfile(fileparts(simPath), [name, '.txt']);
    T         = readtable(txtPath);
    sim       = table2array(T(:, 4));   % column 4 → J11
    sim       = sim(1:72);
end

% -------------------------------------------------------------------------
function stripCommas(simPath)
    [~, name] = fileparts(simPath);
    fpath     = fullfile(fileparts(simPath), [name, '.txt']);
    txt       = fileread(fpath);
    txt       = strrep(txt, ',', '');
    fid       = fopen(fpath, 'w');
    fwrite(fid, txt);
    fclose(fid);
end