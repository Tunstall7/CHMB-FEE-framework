function updateBasin(par, mdlPath, basinName)
    fpath   = fullfile(mdlPath, [basinName, '.basin']);
    subList = {'S1','S2','S3','S4','S5','S6','S7','S8','S9','S10'};

    fid = fopen(fpath, 'r');
    if fid == -1, error('Cannot open file: %s', fpath); end

    out = '';
    idx = -1;
    ln  = fgets(fid);

    while ischar(ln)
        raw  = ln;
        trim = strtrim(ln);

        if contains(trim, 'Subbasin:')
            idx = find(strcmp(subList, strtrim(strrep(trim, 'Subbasin:', ''))), 1);
        end

        if idx > 0
            if contains(raw, 'Initial Abstraction:')
                raw = regexprep(raw, '(Initial Abstraction:\s+)(\S+)', ...
                    ['$1', num2str(par(30+idx), '%0.3f')]);
            elseif contains(raw, 'Curve Number:')
                raw = regexprep(raw, '(Curve Number:\s+)(\S+)', ...
                    ['$1', num2str(par(idx), '%0.3f')]);
            elseif contains(raw, 'Percent Impervious Area:')
                raw = regexprep(raw, '(Percent Impervious Area:\s+)(\S+)', ...
                    ['$1', num2str(par(10+idx), '%0.3f')]);
            elseif contains(raw, 'Lag:')
                raw = regexprep(raw, '(Lag:\s+)(\S+)', ...
                    ['$1', num2str(par(20+idx), '%0.7f')]);
            end
        end

        out = [out, raw]; %#ok<AGROW>
        if ~endsWith(raw, newline), out = [out, newline]; end %#ok<AGROW>
        ln = fgets(fid);
    end
    fclose(fid);

    fid = fopen(fpath, 'w');
    if fid == -1, error('Cannot open file for writing: %s', fpath); end
    fwrite(fid, out);
    fclose(fid);
    disp('Basin file updated.');
end