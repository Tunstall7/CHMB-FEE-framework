function runPyScript(j)
    mdlPath  = 'C:\Projects\HEC\Models\example_model';
    runNames = {'Run01'};
    dssVue   = 'C:\HEC\HEC-DSSVue\install';
    pyPath   = fullfile(mdlPath, 'PyScripts', [runNames{j}, '_Script.py']);

    tic;
    cmd    = sprintf('cd /d "%s" && HEC-DSSVue.exe -s "%s"', dssVue, pyPath);
    status = system(cmd);
    elapsed = toc;

    fprintf('%s\n', repmat('-', 1, 64));
    if status ~= 0
        fprintf('ERROR: HEC-DSSVue run failed.\n');
    else
        fprintf('HEC-DSSVue completed. Elapsed: %.1f s\n', elapsed);
    end
end