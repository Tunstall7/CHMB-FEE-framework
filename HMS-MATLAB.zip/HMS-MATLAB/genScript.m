function genScript(mdlPath, mdlName, j)
    runNames   = {'Run01'};
    scriptPath = fullfile(mdlPath, [runNames{j}, '_compute.script']);

    fid = fopen(scriptPath, 'w');
    if fid == -1, error('Cannot open file: %s', scriptPath); end

    content = sprintf(['from hms.model.JythonHms import *\n', ...
                       'OpenProject("%s", "%s")\n', ...
                       'Compute("%s")\n', ...
                       'Exit(1)'], ...
                       mdlName, strrep(mdlPath, '\', '\\'), runNames{j});

    fprintf(fid, '%s', content);
    fclose(fid);
    disp('Compute script generated.');
end