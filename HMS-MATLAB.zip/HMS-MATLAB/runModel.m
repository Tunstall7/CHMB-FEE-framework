function obj = runModel(par)
    global mdlPath runNames scriptPath expPath pyPath simPath
    mdlPath  = 'C:\Projects\HEC\Models\example_model';
    mdlName  = 'example_model';
    basinName = 'Basin_A';
    runNames = {'Run01'};
    obj = 0;

    for j = 1:numel(runNames)
        scriptPath = fullfile(mdlPath, [runNames{j}, '_compute.script']);
        expPath    = 'C:\Projects\HEC\DSS\export';
        outName    = sprintf('Run%02d_%s', j, runNames{j});
        pyPath     = fullfile(mdlPath, 'PyScripts', [runNames{j}, '_Script.py']);
        simPath    = fullfile(expPath, outName);

        updateBasin(par, mdlPath, basinName);
        genScript(mdlPath, mdlName, j);
        runHMS(scriptPath);
        genPyScript(j);
        runPyScript(j);

        sim = extractSim(j);
        obj = max(sim);
    end
end
