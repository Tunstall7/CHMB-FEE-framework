function runHMS(scriptPath)
    hmsDir  = 'C:\HEC\HEC-HMS-4.x\install';
    tic;
    cmd     = sprintf('cd /d "%s" && HEC-HMS.cmd -s "%s"', hmsDir, scriptPath);
    status  = system(cmd);
    elapsed = toc;

    fprintf('%s\n', repmat('-', 1, 64));
    if status ~= 0
        fprintf('ERROR: HEC-HMS run failed.\n');
    else
        fprintf('HEC-HMS completed. Elapsed: %.1f s\n', elapsed);
    end
end