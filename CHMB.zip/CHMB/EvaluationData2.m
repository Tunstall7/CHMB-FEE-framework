function [opt,data,Net,Loss] = EvaluationData2(opt,data)
if opt.isUseOptimizer
    OptimizedParams =  evalin('base', 'OptimizedParams');
    % find best Net
    [valBest,indxBest] = sort(str2double(extractAfter(strrep(fieldnames(OptimizedParams),'_','.'),'Error')));
    data.BiLSTM.Net = OptimizedParams.(['ValidationError' strrep(num2str(valBest(1)),'.','_')]).Net;
    data.BiLSTM.Loss = OptimizedParams.(['ValidationError' strrep(num2str(valBest(1)),'.','_')]).Loss;
    Net=OptimizedParams.(['ValidationError' strrep(num2str(valBest(1)),'.','_')]).Net;
    Loss=OptimizedParams.(['ValidationError' strrep(num2str(valBest(1)),'.','_')]).Loss;
    disp('save net')
    if opt.isSaveBestOptimizedValue
        fileName = ['BestNet ' num2str(valBest(1)) ' ' char(datetime('now','Format','yyyy.MM.dd HH.mm')) '.mat'];
        Net = data.BiLSTM.Net;
        Loss = data.BiLSTM.Loss;
        save(fileName,'Net')
    end
elseif ~opt.isUseOptimizer
    [chosenfile,chosendirectory] = uigetfile({'*.mat'},...
    'Select Net File','BestNet.mat');
    if chosenfile==0
        error('Please Select saved Network File or set isUseOptimizer: true');
    end
    filePath = [chosendirectory chosenfile];
    Net1 = load(filePath);
    data.BiLSTM.Net = Net1.Net;
    data.BiLSTM.Loss = Net1.Loss;
end

disp(' network performance evaluated.');
end