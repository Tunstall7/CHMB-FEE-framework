function [opt,data] = OptimizeBayeLSTMS_and_CNNS1(opt,data)
if opt.isDispOptimizationLog
    isLog = 2;
else
    isLog = 0;
end
if opt.isUseOptimizer
    opt.ObjFcn  = ObjFcn(opt,data);
    BayesObject = bayesopt(opt.ObjFcn,opt.optimVars, ...
        'MaxTime',opt.MaxOptimizationTime, ...
        'IsObjectiveDeterministic',false, ...
        'MaxObjectiveEvaluations',opt.MaxItrationNumber,...
        'Verbose',isLog,...
        'UseParallel',false);
end

end

% ---------------- objective function
function ObjFcn = ObjFcn(opt,data)
ObjFcn = @CostFunction;

    function [valError,cons,fileName] = CostFunction(optVars)

        inputSize    = size(data.X,2);
        disp(inputSize)
        outputMode   = 'sequence';
        numResponses =opt.roll_num_in;
        % disp(numResponses)
        dropoutVal   = .2;

        if optVars.isUseBiLSTMLayer == 2
            optVars.isUseBiLSTMLayer = 0;
        end
        method_use=opt.methods;   %����
        % if opt.isUseDropoutLayer % if dropout layer is true
        if data.attention_label==0
            if optVars.NumOfLayer ==1
                if strcmp( method_use,'BiLSTM')==1
                    opt.layers = [ ...
                        sequenceInputLayer(inputSize)
                        bilstmLayer(optVars.NumOfUnits,'OutputMode',outputMode)
                        dropoutLayer(dropoutVal)
                        fullyConnectedLayer(numResponses)
                        regressionLayer];
                elseif strcmp( method_use,'LSTM')==1
                    opt.layers = [ ...
                        sequenceInputLayer(inputSize)
                        lstmLayer(optVars.NumOfUnits,'OutputMode',outputMode)
                        dropoutLayer(dropoutVal)
                        fullyConnectedLayer(numResponses)
                        regressionLayer];
                elseif strcmp( method_use,'GRU')==1
                    opt.layers = [ ...
                        sequenceInputLayer(inputSize)
                        gruLayer(optVars.NumOfUnits,'OutputMode',outputMode)
                        dropoutLayer(dropoutVal)
                        fullyConnectedLayer(numResponses)
                        regressionLayer];

                else
                    opt.layers = [ ...
                        sequenceInputLayer(inputSize)
                        lstmLayer(optVars.NumOfUnits,'OutputMode',outputMode)
                        dropoutLayer(dropoutVal)
                        fullyConnectedLayer(numResponses)
                        regressionLayer];
                end
            elseif optVars.NumOfLayer==2
                if strcmp( method_use,'BiLSTM')==1
                    opt.layers = [ ...
                        sequenceInputLayer(inputSize)
                        bilstmLayer(optVars.NumOfUnits,'OutputMode',outputMode)
                        dropoutLayer(dropoutVal)
                        bilstmLayer(optVars.NumOfUnits,'OutputMode',outputMode)
                        dropoutLayer(dropoutVal)
                        fullyConnectedLayer(numResponses)
                        regressionLayer];
                elseif strcmp( method_use,'LSTM')==1
                    opt.layers = [ ...
                        sequenceInputLayer(inputSize)
                        lstmLayer(optVars.NumOfUnits,'OutputMode',outputMode)
                        dropoutLayer(dropoutVal)
                        lstmLayer(optVars.NumOfUnits,'OutputMode',outputMode)
                        dropoutLayer(dropoutVal)
                        fullyConnectedLayer(numResponses)
                        regressionLayer];
                elseif strcmp( method_use,'GRU')==1
                    opt.layers = [ ...
                        sequenceInputLayer(inputSize)
                        gruLayer(optVars.NumOfUnits,'OutputMode',outputMode)
                        dropoutLayer(dropoutVal)
                        gruLayer(optVars.NumOfUnits,'OutputMode',outputMode)
                        dropoutLayer(dropoutVal)
                        fullyConnectedLayer(numResponses)
                        regressionLayer];

                else
                    opt.layers = [ ...
                        sequenceInputLayer(inputSize)
                        lstmLayer(optVars.NumOfUnits,'OutputMode',outputMode)
                        dropoutLayer(dropoutVal)
                        lstmLayer(optVars.NumOfUnits,'OutputMode',outputMode)
                        dropoutLayer(dropoutVal)
                        fullyConnectedLayer(numResponses)
                        regressionLayer];
                end
            end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        else
            if optVars.NumOfLayer ==1
                if strcmp( method_use,'BiLSTM')==1
                    opt.layers = [ ...
                        sequenceInputLayer(inputSize)
                        bilstmLayer(optVars.NumOfUnits,'OutputMode',outputMode)
                        selfAttentionLayer(data.attention_head(1),data.attention_head(2))
                        dropoutLayer(dropoutVal)
                        fullyConnectedLayer(numResponses)
                        regressionLayer];
                elseif strcmp( method_use,'LSTM')==1
                    opt.layers = [ ...
                        sequenceInputLayer(inputSize)
                        lstmLayer(optVars.NumOfUnits,'OutputMode',outputMode)
                        selfAttentionLayer(data.attention_head(1),data.attention_head(2))
                        dropoutLayer(dropoutVal)
                        fullyConnectedLayer(numResponses)
                        regressionLayer];
                elseif strcmp( method_use,'GRU')==1
                    opt.layers = [ ...
                        sequenceInputLayer(inputSize)
                        gruLayer(optVars.NumOfUnits,'OutputMode',outputMode)
                        selfAttentionLayer(data.attention_head(1),data.attention_head(2))
                        dropoutLayer(dropoutVal)
                        fullyConnectedLayer(numResponses)
                        regressionLayer];

                else
                    opt.layers = [ ...
                        sequenceInputLayer(inputSize)
                        lstmLayer(optVars.NumOfUnits,'OutputMode',outputMode)
                        selfAttentionLayer(data.attention_head(1),data.attention_head(2))
                        dropoutLayer(dropoutVal)
                        fullyConnectedLayer(numResponses)
                        regressionLayer];
                end
            elseif optVars.NumOfLayer==2
                if strcmp( method_use,'BiLSTM')==1
                    opt.layers = [ ...
                        sequenceInputLayer(inputSize)
                        bilstmLayer(optVars.NumOfUnits,'OutputMode',outputMode)
                        dropoutLayer(dropoutVal)
                        bilstmLayer(optVars.NumOfUnits,'OutputMode',outputMode)
                        selfAttentionLayer(data.attention_head(1),data.attention_head(2))
                        dropoutLayer(dropoutVal)
                        fullyConnectedLayer(numResponses)
                        regressionLayer];
                elseif strcmp( method_use,'LSTM')==1
                    opt.layers = [ ...
                        sequenceInputLayer(inputSize)
                        lstmLayer(optVars.NumOfUnits,'OutputMode',outputMode)
                        dropoutLayer(dropoutVal)
                        lstmLayer(optVars.NumOfUnits,'OutputMode',outputMode)
                        selfAttentionLayer(data.attention_head(1),data.attention_head(2))
                        dropoutLayer(dropoutVal)
                        fullyConnectedLayer(numResponses)
                        regressionLayer];
                elseif strcmp( method_use,'GRU')==1
                    opt.layers = [ ...
                        sequenceInputLayer(inputSize)
                        gruLayer(optVars.NumOfUnits,'OutputMode',outputMode)
                        dropoutLayer(dropoutVal)
                        gruLayer(optVars.NumOfUnits,'OutputMode',outputMode)
                        selfAttentionLayer(data.attention_head(1),data.attention_head(2))
                        dropoutLayer(dropoutVal)
                        fullyConnectedLayer(numResponses)
                        regressionLayer];

                else
                    opt.layers = [ ...
                        sequenceInputLayer(inputSize)
                        lstmLayer(optVars.NumOfUnits,'OutputMode',outputMode)
                        dropoutLayer(dropoutVal)
                        lstmLayer(optVars.NumOfUnits,'OutputMode',outputMode)
                        selfAttentionLayer(data.attention_head(1),data.attention_head(2))
                        dropoutLayer(dropoutVal)
                        fullyConnectedLayer(numResponses)
                        regressionLayer];
                end
            end
        end

        miniBatchSize    = opt.miniBatchSize;
        maxEpochs        = opt.maxEpochs;
        trainingProgress = opt.trainingProgress;
        executionEnvironment = opt.executionEnvironment;
        validationFrequency  = floor(numel(data.XTr)/miniBatchSize);

        opt.opts = trainingOptions(opt.LR, ...
            'MaxEpochs',maxEpochs, ...
            'GradientThreshold',1, ...
            'InitialLearnRate',optVars.InitialLearnRate, ...
            'LearnRateSchedule','piecewise', ...
            'LearnRateDropPeriod',125, ...
            'LearnRateDropFactor',0.2, ...
            'L2Regularization',optVars.L2Regularization, ...
            'Verbose',1, ...
            'MiniBatchSize',miniBatchSize,...
            'ExecutionEnvironment',executionEnvironment,...
            'ValidationFrequency',validationFrequency,....
            'Plots',trainingProgress);
        disp('net architect successfully created.');

        % --------------- Train Network
        try
            [data.BiLSTM.Net,data.BiLSTM.Loss] = trainNetwork(data.XTr,data.YTr,opt.layers,opt.opts);
            disp(' Netwwork successfully trained.');
            data.IsNetTrainSuccess =true;
        catch me
            disp('Error on Training LSTM Network');
            data.IsNetTrainSuccess = false;
            return;
        end

      data_get_pre=predict(data.BiLSTM.Net,data.XVl,'MiniBatchSize',opt.miniBatchSize);
    data_get_pre_true=data.YVl;
    for i=1:length(data_get_pre)
         data_get_pre1(i,:) = (data_get_pre{i,1});               
         data_get_pre_true1(i,:) = (data_get_pre_true{i,1});       
    end
    
    % save test_data data_get_111
    valError = mean(mse(data_get_pre1-data_get_pre_true1));      


        Net  = data.BiLSTM.Net;
        Loss=data.BiLSTM.Loss;
        Opts = opt.opts;

        fieldName = ['ValidationError' strrep(num2str(valError),'.','_')];
        if ismember('OptimizedParams',evalin('base','who'))
            OptimizedParams =  evalin('base', 'OptimizedParams');
            OptimizedParams.(fieldName).Net  = Net;
            OptimizedParams.(fieldName).Opts = Opts;
            OptimizedParams.(fieldName).Loss = Loss;
            assignin('base','OptimizedParams',OptimizedParams);
        else
            OptimizedParams.(fieldName).Net  = Net;
            OptimizedParams.(fieldName).Opts = Opts;
            OptimizedParams.(fieldName).Loss = Loss;
            assignin('base','OptimizedParams',OptimizedParams);
        end

        fileName = num2str(valError) + ".mat";
        if opt.isSaveOptimizedValue
            save(fileName,'Net','valError','Opts','Loss')
        end
        cons = [];

    end

end