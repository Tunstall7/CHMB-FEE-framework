clc; clear; close all;

%% ========================================================================
%  BiLSTM + Bayesian Hyperparameter Optimization  |  Time Series Forecast
%  Metrics: KGE | MAE | RMSE | R2 | NSE
% =========================================================================

load('MT_23_Jul_2025_22_58_46.mat')
rng(G_out_data.random_seed)

%% ------------------------------------------------------------------------
%  1. Load and parse training data
% -------------------------------------------------------------------------
raw   = readtable(G_out_data.data_path_str, 'VariableNamingRule', 'preserve');
tbl   = raw(:, 2:end);
probe = table2cell(raw(1, 2:end));

% Detect column types
col_type = zeros(1, numel(probe));
for k = 1:numel(probe)
    if     ischar   (probe{k}),  col_type(k) = 1;   % categorical
    elseif isnumeric(probe{k}),  col_type(k) = 2;   % numeric
    end
end
cat_cols = find(col_type == 1);
num_cols = find(col_type == 2);

% Numeric block
if ~isempty(num_cols)
    num_blk     = table2array(tbl(:, num_cols));
    active_cols = num_cols;
else
    num_blk     = [];
    active_cols = num_cols;
end

% Categorical block (integer label encoding)
cat_blk = [];
if ~isempty(cat_cols)
    for j = 1:numel(cat_cols)
        col    = table2array(tbl(:, cat_cols(j)));
        levels = unique(col);
        for lv = 1:numel(levels)
            cat_blk(ismember(col, levels{lv}), j) = lv;
        end
    end
end

X_raw     = [cat_blk, num_blk];
col_order = [cat_cols, active_cols];
feat_names = tbl.Properties.VariableNames(col_order);

% Spline interpolation over NaN gaps
X_clean = zeros(size(X_raw));
for c = 1:size(X_raw, 2)
    col   = X_raw(:, c);
    valid = ~isnan(col);
    ia    = 1:numel(col);
    X_clean(:, c) = interp1(ia(valid), col(valid), ia, 'spline');
end

%% ------------------------------------------------------------------------
%  2. Configuration
% -------------------------------------------------------------------------
cfg.n_pred   = G_out_data.predict_num_set;
cfg.n_feat   = G_out_data.num_feature;
cfg.n_series = G_out_data.num_series;
cfg.n_sel    = G_out_data.select_predict_num;
cfg.bsz      = G_out_data.min_batchsize;
cfg.roll_in  = G_out_data.roll_num_in;
cfg.n_bo     = G_out_data.num_BO_iter;
cfg.epochs   = G_out_data.max_epoch_LC;
cfg.list     = G_out_data.list_cell;
cfg.att_lbl  = G_out_data.attention_label;
cfg.att_head = G_out_data.attention_head;
cfg.split    = G_out_data.spilt_ri;
cfg.tag      = G_out_data.Tvalue;

feat_cols = 1 : size(X_clean, 2) - cfg.n_pred;   % input feature column indices
D         = X_clean;                              % working data matrix

% Single-component cell (extendable for decomposition)
seg = {D};

%% ------------------------------------------------------------------------
%  3. Training loop
% -------------------------------------------------------------------------
mu_x = []; sig_x = []; mu_y = []; sig_y = [];

for s = 1:numel(seg)

    [Xf, Yf] = timeseries_process1(seg{s}, cfg.n_sel, cfg.n_feat, cfg.n_series);
    [~,  Y0] = timeseries_process1(D,       cfg.n_sel, cfg.n_feat, cfg.n_series);

    % Split indices
    N    = size(Xf, 1);
    n_tr = round(cfg.split(1) / sum(cfg.split) * N);
    n_va = round(sum(cfg.split(1:2)) / sum(cfg.split) * N);
    idx  = 1:N;

    tr_X = Xf(idx(1:n_tr),       :);  tr_Y = Yf(idx(1:n_tr),       :);
    va_X = Xf(idx(n_tr+1:n_va),  :);  va_Y = Yf(idx(n_tr+1:n_va),  :);
    te_X = Xf(idx(n_va+1:end),   :);  te_Y = Yf(idx(n_va+1:end),   :);

    % Z-score (fit on train only)
    mx = mean(tr_X);  sx = std(tr_X);
    my = mean(tr_Y);  sy = std(tr_Y);

    tr_Xn = (tr_X - mx) ./ sx;  tr_Yn = (tr_Y - my) ./ sy;
    va_Xn = (va_X - mx) ./ sx;  va_Yn = (va_Y - my) ./ sy;
    te_Xn = (te_X - mx) ./ sx;  te_Yn = (te_Y - my) ./ sy;

    mu_x(s,:) = mx;  sig_x(s,:) = sx;
    mu_y(s,:) = my;  sig_y(s,:) = sy;

    % Pre-allocate normalised prediction buffers
    yhat_tr_n = zeros(size(tr_Y));
    yhat_va_n = zeros(size(va_Y));
    yhat_te_n = zeros(size(te_Y));

    for g = 1:numel(cfg.list)

        % Pack into sequence cell arrays
        Ctr_x = mat2seq(tr_Xn);  Ctr_y = mat2seq(tr_Yn(:, cfg.list{g}));
        Cva_x = mat2seq(va_Xn);  Cva_y = mat2seq(va_Yn(:, cfg.list{g}));
        Cte_x = mat2seq(te_Xn);  Cte_y = mat2seq(te_Yn(:, cfg.list{g}));

        % Data bundle
        ds           = struct();
        ds.X         = Xf;      ds.Y   = Yf;
        ds.XTr       = Ctr_x;   ds.YTr = Ctr_y;
        ds.XVl       = Cva_x;   ds.YVl = Cva_y;
        ds.XTs       = Cte_x;   ds.YTs = Cte_y;
        ds.attention_label = cfg.att_lbl;
        ds.attention_head  = cfg.att_head;

        % Bayesian optimisation + training
        opt        = build_opt(cfg);
        [opt, ds]  = OptimizeBayeLSTMS_and_CNNS1(opt, ds);
        [~, ds, ~, loss] = EvaluationData2(opt, ds);

        net = ds.BiLSTM.Net;

        % Inference on all partitions
        yhat_tr_n(:, cfg.list{g}) = seq2mat(predict(net, Ctr_x, 'MiniBatchSize', opt.miniBatchSize));
        yhat_va_n(:, cfg.list{g}) = seq2mat(predict(net, Cva_x, 'MiniBatchSize', opt.miniBatchSize));
        yhat_te_n(:, cfg.list{g}) = seq2mat(predict(net, Cte_x, 'MiniBatchSize', opt.miniBatchSize));

        nets{s, g} = net;

        % Network graph
        figure; plot(layerGraph(net.Layers));
        title('BiLSTM Architecture');

        % Loss curves
        figure
        subplot(2,1,1)
        plot(loss.TrainingRMSE, '-', 'LineWidth', 1);
        xlabel('Epoch'); ylabel('RMSE'); title('Training RMSE'); grid on;
        subplot(2,1,2)
        plot(loss.TrainingLoss, '-', 'LineWidth', 1);
        xlabel('Epoch'); ylabel('Loss'); title('Training Loss'); grid on;
        set(gcf, 'color', 'w')
    end

    % Inverse normalise
    Yhat_tr{s} = yhat_tr_n .* sy + my;
    Yhat_va{s} = yhat_va_n .* sy + my;
    Yhat_te{s} = yhat_te_n .* sy + my;
end

% Sum decomposition components
Yhat_tr_sum = sum(cat(3, Yhat_tr{:}), 3);
Yhat_va_sum = sum(cat(3, Yhat_va{:}), 3);
Yhat_te_sum = sum(cat(3, Yhat_te{:}), 3);

% Ground-truth (original un-decomposed series)
Ytr = Y0(idx(1:n_tr),      :);
Yva = Y0(idx(n_tr+1:n_va), :);
Yte = Y0(idx(n_va+1:end),  :);

%% ------------------------------------------------------------------------
%  4. Evaluation
% -------------------------------------------------------------------------
fprintf('\n');
eval_metrics(cfg.tag, 'Train',      Ytr, Yhat_tr_sum);
eval_metrics(cfg.tag, 'Validation', Yva, Yhat_va_sum);
eval_metrics(cfg.tag, 'Test',       Yte, Yhat_te_sum);

%% ------------------------------------------------------------------------
%  5. Rolling forecast  (post-validation horizon, ALL steps retained)
% -------------------------------------------------------------------------
Yhat_roll = cell(1, numel(seg));

for s = 1:numel(seg)
    tail = seg{s}(n_va+1:end, :);
    Xp   = timeseries_process1_Pre(tail, cfg.n_sel, cfg.n_feat, cfg.n_series);
    Xpn  = (Xp - mu_x(s,:)) ./ sig_x(s,:);
    Cp   = mat2seq(Xpn);

    Zpn  = zeros(size(Xp,1), size(Ytr,2));
    for g = 1:numel(cfg.list)
        Zpn(:, cfg.list{g}) = seq2mat(predict(nets{s,g}, Cp, 'MiniBatchSize', cfg.bsz));
    end
    Yhat_roll{s} = Zpn .* sig_y(s,:) + mu_y(s,:);
end

% All predicted rows are retained (full horizon, not just the last step)
Yhat_fwd = sum(cat(3, Yhat_roll{:}), 3);
Y_ref    = sum(cat(2, cellfun(@(c) c(n_va+1:end, end), seg, 'UniformOutput', false)), 2);

fprintf('\nRolling forecast  (%d steps x %d outputs):\n', size(Yhat_fwd,1), size(Yhat_fwd,2));
disp(Yhat_fwd)

figure;
plot(Y_ref, '-o', 'LineWidth', 1); hold on;
t_fwd = numel(Y_ref) + (1:size(Yhat_fwd,1));
plot(t_fwd, Yhat_fwd(:,1), '-p', 'LineWidth', 1.2)
legend('Reference', 'Forecast');
xlabel('Time Step'); ylabel('Value');
title('Rolling Forecast'); grid on;
set(gca, 'LineWidth', 1.2); set(gcf, 'color', 'w')

%% ------------------------------------------------------------------------
%  6. Inference on external (unseen) data
% -------------------------------------------------------------------------
raw2   = readtable(G_out_data.predict_str, 'VariableNamingRule', 'preserve');
tbl2   = raw2(:, 2:end);
probe2 = table2cell(raw2(1, 2:end));

col_type2 = zeros(1, numel(probe2));
for k = 1:numel(probe2)
    if     ischar   (probe2{k}),  col_type2(k) = 1;
    elseif isnumeric(probe2{k}),  col_type2(k) = 2;
    end
end
cat_cols2 = find(col_type2 == 1);
num_cols2 = find(col_type2 == 2);

if ~isempty(num_cols2)
    num_blk2     = table2array(tbl2(:, num_cols2));
    active_cols2 = num_cols2;
else
    num_blk2     = [];
    active_cols2 = num_cols2;
end

cat_blk2 = [];
if ~isempty(cat_cols2)
    for j = 1:numel(cat_cols2)
        col2  = table2array(tbl2(:, cat_cols2(j)));
        levs2 = unique(col2);
        for lv = 1:numel(levs2)
            cat_blk2(ismember(col2, levs2{lv}), j) = lv;
        end
    end
end

X_ext_raw = [cat_blk2, num_blk2];
X_ext     = zeros(size(X_ext_raw));
for c = 1:size(X_ext_raw, 2)
    col   = X_ext_raw(:, c);
    valid = ~isnan(col);
    ia    = 1:numel(col);
    X_ext(:, c) = interp1(ia(valid), col(valid), ia, 'spline');
end

% Align feature columns with training layout
D_ext = [X_ext(:, feat_cols), X_ext(:, end-cfg.n_pred+1:end)];

% Flag mask: history = 1, new = 0  (excludes boundary-crossing windows)
D_aug   = [D; D_ext];
flag    = [ones(size(D,1),1); zeros(size(D_ext,1),1)];
D_aug_f = D_aug;  D_aug_f(:, end) = flag;

Yhat_ext_cell = cell(1, 1);

Xp_aug  = timeseries_process1_Pre(D_aug,   cfg.n_sel, cfg.n_feat, cfg.n_series);
Xp_flag = timeseries_process1_Pre(D_aug_f, cfg.n_sel, cfg.n_feat, cfg.n_series);
Xp_new  = Xp_aug(Xp_flag(:, end) == 0, :);  % unseen windows only

Xpn = (Xp_new - mu_x(1,:)) ./ sig_x(1,:);
Cp  = mat2seq(Xpn);

Zpn = zeros(size(Xp_new,1), size(Ytr,2));
for g = 1:numel(cfg.list)
    Zpn(:, cfg.list{g}) = seq2mat(predict(nets{1,g}, Cp, 'MiniBatchSize', cfg.bsz));
end

% All rows retained in final output
Y_ext = Zpn .* sig_y(1,:) + mu_y(1,:);

fprintf('\nExternal inference complete.  Y_ext  [%d x %d]\n', size(Y_ext,1), size(Y_ext,2));
disp(Y_ext)


%% ========================================================================
%  LOCAL UTILITIES
% =========================================================================

function C = mat2seq(M)
% [N x F] matrix  ->  N x 1 cell of column vectors  (LSTM sequence format)
    C = arrayfun(@(i) M(i,:)', 1:size(M,1), 'UniformOutput', false)';
end

% -------------------------------------------------------------------------
function M = seq2mat(C)
% N x 1 prediction cell  ->  [N x P] matrix
    M = cell2mat(cellfun(@(v) v(:)', C, 'UniformOutput', false));
end

% -------------------------------------------------------------------------
function opt = build_opt(cfg)
% Assemble the BiLSTM / Bayesian optimiser options struct
    opt.methods                  = 'LSTM';
    opt.maxEpochs                = cfg.epochs;
    opt.miniBatchSize            = cfg.bsz;
    opt.executionEnvironment     = 'auto';
    opt.LR                       = 'adam';
    opt.trainingProgress         = 'none';
    opt.isUseBiLSTMLayer         = true;
    opt.isUseDropoutLayer        = true;
    opt.DropoutValue             = 0.2;
    opt.roll_num_in              = cfg.roll_in;
    opt.isUseOptimizer           = true;
    opt.isSaveOptimizedValue     = false;
    opt.isSaveBestOptimizedValue = true;
    opt.MaxOptimizationTime      = 14 * 3600;
    opt.MaxItrationNumber        = cfg.n_bo;
    opt.isDispOptimizationLog    = true;
    opt.optimVars = [
        optimizableVariable('NumOfLayer',       [1   2],      'Type','integer')
        optimizableVariable('NumOfUnits',       [50  200],    'Type','integer')
        optimizableVariable('isUseBiLSTMLayer', [1   2],      'Type','integer')
        optimizableVariable('InitialLearnRate', [1e-2  1],    'Transform','log')
        optimizableVariable('L2Regularization', [1e-10 1e-2], 'Transform','log')];
end

% -------------------------------------------------------------------------
function eval_metrics(tag, label, Yo, Yp)
% Print KGE | MAE | RMSE | R2 | NSE
    n    = numel(Yo);
    e    = Yo(:) - Yp(:);
    yo   = Yo(:);  yp = Yp(:);

    MAE  = sum(abs(e))  / n;
    RMSE = sqrt(sum(e.^2) / n);
    ss_r = sum(e.^2);
    ss_t = sum((yo - mean(yo)).^2);
    R2   = 1 - ss_r / ss_t;
    NSE  = R2;

    rc  = corrcoef(yo, yp);
    r   = rc(1,2);
    KGE = 1 - sqrt((r-1)^2 + (std(yp)/std(yo)-1)^2 + (mean(yp)/mean(yo)-1)^2);

    fprintf('[%s]  %s\n',       tag, label);
    fprintf('  KGE  : %10.6f\n', KGE);
    fprintf('  MAE  : %10.6f\n', MAE);
    fprintf('  RMSE : %10.6f\n', RMSE);
    fprintf('  R2   : %10.6f\n', R2);
    fprintf('  NSE  : %10.6f\n', NSE);
    fprintf('  %s\n', repmat('-',1,38));
end